# Enjoy

Firmware for [Enjoy](https://github.com/myst729/enjoy). An extremely borderless mechanical keyboard. 40% staggered layout with an analog joystick.

## Implemented QMK features

- [ ] OLED Driver
- [x] Backlight
- [ ] LED Matrix
- [ ] RGB Lighting
- [ ] RGB Matrix
- [ ] Audio
- [ ] Bluetooth
- [ ] Li-Po Charger
- [ ] Encoders
- [x] Joystick
- [x] LED Indicators
- [ ] RGB Indicators
- [ ] PS/2 Mouse
